import AVFoundation
import SwiftUI
import WebKit

private let purple = Color(red: 0.17, green: 0.10, blue: 0.28)
private let gold = Color(red: 1, green: 0.82, blue: 0.35)
private let gameURL = URL(string: "https://pokeidle.io/app")!

struct BallLimit: Codable {
    var reserve = 0
    var min: Int?
    var max: Int?
}

struct Settings: Decodable {
    var capture: Bool
    var buy: Bool
    var stock: [String: BallLimit]
}

struct Capture: Decodable {
    var at: Double
    var text: String
    var Account: String?
    var Name: String?
    var Photo: String?
    var Level: Double?
    var Power: Double?
    var Quality: Double?
    var Iv: Double?
    var Note: Double?
    var Ball: Int?
    var Shiny: Bool?
}

struct Farm: Decodable {
    struct Item: Decodable {
        var name: String
        var quantity: Int
    }
    var day: String
    var gold: Int
    var items: [Item]
}

struct Snapshot: Decodable {
    var nick: String
    var gold: Int?
    var stock: [String: Int]?
    var config: Settings
    var history: [Capture]
    var farm: [Farm]
    var status: String
    var online: Bool?
    var lastSignal: Double?
    var sessionStart: Double?
    var sessionCaptures: Int?
    var sessionShinies: Int?
    var `throws`: [String: Int]
}

@MainActor
final class Profile: NSObject, ObservableObject, WKScriptMessageHandler, WKNavigationDelegate {
    @Published var state: Snapshot?
    @Published var error: String?
    let web: WKWebView
    private var started = false
    private var active = false
    private var captureSound: AVAudioPlayer?

    init(slot: Int) {
        let key = "bugo-profile-\(slot)"
        let defaults = UserDefaults.standard
        let id = defaults.string(forKey: key).flatMap(UUID.init(uuidString:)) ?? UUID()
        defaults.set(id.uuidString, forKey: key)
        let config = WKWebViewConfiguration()
        config.websiteDataStore = WKWebsiteDataStore(forIdentifier: id)
        let script = Bundle.main.url(forResource: "Automation", withExtension: "js")
            .flatMap { try? String(contentsOf: $0, encoding: .utf8) }
        if let script {
            config.userContentController.addUserScript(WKUserScript(
                source: script, injectionTime: .atDocumentStart, forMainFrameOnly: true
            ))
        }
        web = WKWebView(frame: .zero, configuration: config)
        super.init()
        config.userContentController.add(self, name: "bugo")
        web.navigationDelegate = self
        if script == nil { error = "Automação indisponível nesta compilação." }
    }

    func open() {
        guard !started else { return }
        reload()
    }

    func reload() {
        started = true
        state = nil
        web.load(URLRequest(url: gameURL))
    }

    func setActive(_ value: Bool) {
        active = value
        if started { web.evaluateJavaScript("window.bugoAtivo?.(\(value))", completionHandler: nil) }
    }

    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        let frame = message.frameInfo
        guard frame.isMainFrame, frame.securityOrigin.protocol == "https",
              frame.securityOrigin.host == "pokeidle.io", web.url?.host == "pokeidle.io",
              web.url?.path.hasPrefix("/app") == true,
              JSONSerialization.isValidJSONObject(message.body),
              let data = try? JSONSerialization.data(withJSONObject: message.body),
              let snapshot = try? JSONDecoder().decode(Snapshot.self, from: data) else { return }
        let newCapture = active && !snapshot.nick.isEmpty
            && state?.nick == snapshot.nick
            && state?.sessionStart == snapshot.sessionStart
            && (snapshot.sessionCaptures ?? 0) > (state?.sessionCaptures ?? 0)
        state = snapshot
        if newCapture { playCaptureSound() }
    }

    private func playCaptureSound() {
        if captureSound == nil,
           let url = Bundle.main.url(forResource: "CaptureAlert", withExtension: "wav") {
            captureSound = try? AVAudioPlayer(contentsOf: url)
        }
        captureSound?.currentTime = 0
        captureSound?.play()
    }

    func webView(_ view: WKWebView, didFinish navigation: WKNavigation!) {
        setActive(active)
    }

    func webView(_ view: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        state = nil
        error = nil
    }

    func webView(_ view: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError failure: Error) {
        guard (failure as NSError).code != NSURLErrorCancelled else { return }
        error = failure.localizedDescription
    }

    func webViewWebContentProcessDidTerminate(_ view: WKWebView) {
        state = nil
        error = "O iOS encerrou a página do jogo. Use Recarregar."
    }

    func clearHistory(nick: String) async {
        do {
            let result = try await web.callAsyncJavaScript(
                "return window.bugoLimpar?.(nick) ?? false",
                arguments: ["nick": nick], in: nil, contentWorld: .page
            )
            if result as? Bool != true { error = "Não foi possível limpar as capturas." }
        } catch {
            self.error = error.localizedDescription
        }
    }

    func save(nick: String, capture: Bool, buy: Bool, stock: [String: BallLimit]) async throws {
        let data = try JSONEncoder().encode(stock)
        let limits = try JSONSerialization.jsonObject(with: data)
        let result = try await web.callAsyncJavaScript(
            "return window.bugoSalvar?.(nick, capture, buy, limits) ?? false",
            arguments: ["nick": nick, "capture": capture, "buy": buy, "limits": limits],
            in: nil, contentWorld: .page
        )
        guard result as? Bool == true else {
            throw NSError(domain: "BugoIdle", code: 1, userInfo: [
                NSLocalizedDescriptionKey: "Confira a conexão, os limites e se há uma compra em andamento."
            ])
        }
    }
}

struct GameView: UIViewRepresentable {
    let profile: Profile
    func makeUIView(context: Context) -> WKWebView { profile.web }
    func updateUIView(_ view: WKWebView, context: Context) {}
}

@MainActor
final class Accounts: ObservableObject {
    let profiles = (1...4).map { Profile(slot: $0) }

    func activate(_ active: Bool) {
        for profile in profiles { profile.setActive(active) }
    }
}

@main
struct BugoIdleApp: App {
    @StateObject private var accounts = Accounts()
    @Environment(\.scenePhase) private var phase
    @State private var slot = 0
    @State private var tab = "Contas"
    @State private var expanded: Set<Int> = []

    var body: some Scene {
        WindowGroup {
            VStack(spacing: 12) {
                HStack {
                    Image(systemName: "circle.lefthalf.filled").foregroundStyle(.red)
                    Text("BUGO-IDLE").font(.system(.headline, design: .monospaced))
                    Spacer()
                    Text("Beta privada").font(.caption).foregroundStyle(.secondary)
                }
                HStack {
                    ForEach(0..<4) { index in
                        Button("Conta \(index + 1)") { slot = index }
                            .font(.caption.bold()).frame(maxWidth: .infinity, minHeight: 44)
                            .background(slot == index ? gold.opacity(0.25) : purple, in: RoundedRectangle(cornerRadius: 8))
                    }
                }
                ZStack {
                    ForEach(accounts.profiles.indices, id: \.self) { index in
                        let visible = index == slot && tab == "Contas" && expanded.contains(index)
                        GameView(profile: accounts.profiles[index])
                            .padding(.top, 44)
                            .opacity(visible ? 1 : 0.015)
                            .allowsHitTesting(visible)
                            .accessibilityHidden(!visible)
                            .zIndex(visible ? 2 : 0)
                    }
                    Color(red: 0.09, green: 0.06, blue: 0.16).zIndex(1)
                    if tab == "Contas" && expanded.contains(slot) {
                        VStack {
                            HStack {
                                Button("Recolher jogo") { expanded.remove(slot) }
                                Spacer()
                                Button("Recarregar") { accounts.profiles[slot].reload() }
                            }
                            .padding(8)
                            Spacer().allowsHitTesting(false)
                        }.zIndex(3)
                    } else {
                        ProfileScreen(profile: accounts.profiles[slot], slot: slot, tab: tab) {
                            accounts.profiles[slot].open()
                            expanded.insert(slot)
                        }.id(slot).zIndex(3)
                    }
                }
                .clipped()
                HStack {
                    nav("Contas", "square.grid.2x2")
                    nav("Capturas", "scope")
                    nav("Ajustes", "gearshape")
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
            .background(Color(red: 0.09, green: 0.06, blue: 0.16).ignoresSafeArea())
            .preferredColorScheme(.dark).tint(gold)
            .onChange(of: phase, initial: true) { _, current in
                let active = current == .active
                UIApplication.shared.isIdleTimerDisabled = active
                accounts.activate(active)
            }
        }
    }

    private func nav(_ name: String, _ icon: String) -> some View {
        Button { tab = name } label: {
            Label(name, systemImage: icon).labelStyle(.vertical)
                .font(.caption).frame(maxWidth: .infinity, minHeight: 48)
                .foregroundStyle(tab == name ? gold : Color.secondary)
                .background(tab == name ? purple : .clear, in: RoundedRectangle(cornerRadius: 10))
        }
    }
}

struct VerticalLabel: LabelStyle {
    func makeBody(configuration: Configuration) -> some View {
        VStack(spacing: 5) { configuration.icon; configuration.title }
    }
}

extension LabelStyle where Self == VerticalLabel {
    static var vertical: VerticalLabel { VerticalLabel() }
}

struct ProfileScreen: View {
    @ObservedObject var profile: Profile
    let slot: Int
    let tab: String
    let showGame: () -> Void

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                switch tab {
                case "Capturas": CaptureHistory(profile: profile)
                case "Ajustes":
                    Text("Automações").font(.title2.bold())
                    if let state = profile.state, !state.nick.isEmpty {
                        AutomationForm(profile: profile, snapshot: state).id(state.nick)
                    } else {
                        Text("Abra o jogo e entre na conta para configurar.")
                    }
                default: overview
                }
                if let error = profile.error { Text(error).foregroundStyle(.red) }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private var overview: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Minhas contas").font(.title2.bold())
            VStack(alignment: .leading, spacing: 12) {
                Text(profile.state.flatMap { $0.nick.isEmpty ? nil : $0.nick } ?? "Conta \(slot + 1)")
                    .font(.headline)
                Divider()
                HStack {
                    metric("Capturas", profile.state?.history.count.formatted() ?? "—")
                    metric("Ouro no jogo", profile.state?.gold?.formatted() ?? "—")
                }
                Button(action: showGame) { Text("Abrir jogo")
                        .frame(maxWidth: .infinity, minHeight: 32)
                }
                .buttonStyle(.borderedProminent).foregroundStyle(.black)
            }
            .padding().background(purple, in: RoundedRectangle(cornerRadius: 12))
            if let state = profile.state, !state.nick.isEmpty {
                Text(state.status).font(.footnote).foregroundStyle(.secondary)
                VStack(alignment: .leading, spacing: 7) {
                    Text("Pokébolas").font(.headline)
                    ForEach(["4", "2", "1"], id: \.self) { id in
                        LabeledContent(ballName(id), value: state.stock?[id]?.formatted() ?? "—")
                    }
                }.padding().background(purple, in: RoundedRectangle(cornerRadius: 12))
            }
        }
    }

    private func metric(_ label: String, _ value: String) -> some View {
        VStack(alignment: .leading) {
            Text(value).font(.headline)
            Text(label).font(.caption).foregroundStyle(.secondary)
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
}

private func ballName(_ id: String) -> String {
    ["4": "Ultra Ball", "2": "Great Ball", "1": "Poké Ball"][id] ?? id
}

struct AutomationForm: View {
    @ObservedObject var profile: Profile
    let snapshot: Snapshot
    @State private var capture = false
    @State private var buy = false
    @State private var minimum: [String: String] = [:]
    @State private var maximum: [String: String] = [:]
    @State private var feedback = ""
    @State private var saving = false
    private let ids = ["4", "2", "1"]

    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Toggle("Captura automática", isOn: $capture)
            Text("Prioridade Ultra → Great → Poké").font(.caption).foregroundStyle(.secondary)
            Divider()
            Toggle("Recompra de bolas", isOn: $buy)
            ForEach(ids, id: \.self) { id in
                Text(ballName(id)).font(.subheadline.bold())
                HStack {
                    input("Mínimo", id: id, values: $minimum)
                    input("Máximo", id: id, values: $maximum)
                }
            }
            Button("Salvar") { Task { await save() } }.buttonStyle(.borderedProminent).disabled(saving)
            if !feedback.isEmpty { Text(feedback).font(.footnote) }
            Text(snapshot.status).font(.footnote).foregroundStyle(.secondary)
        }
        .padding().background(purple, in: RoundedRectangle(cornerRadius: 12))
        .onAppear {
            capture = snapshot.config.capture
            buy = snapshot.config.buy
            for id in ids {
                minimum[id] = snapshot.config.stock[id]?.min.map(String.init)
                maximum[id] = snapshot.config.stock[id]?.max.map(String.init)
            }
        }
    }

    private func input(_ label: String, id: String, values: Binding<[String: String]>) -> some View {
        TextField(label, text: Binding(
            get: { values.wrappedValue[id] ?? "" },
            set: { values.wrappedValue[id] = $0 }
        )).textFieldStyle(.roundedBorder).keyboardType(.numberPad)
    }

    private func save() async {
        var stock: [String: BallLimit] = [:]
        for id in ids {
            let low = minimum[id] ?? ""
            let high = maximum[id] ?? ""
            if low.isEmpty && high.isEmpty {
                stock[id] = BallLimit()
            } else if let min = Int(low), let max = Int(high), min >= 0, max > min, max <= 9_007_199_254_740_991 {
                stock[id] = BallLimit(min: min, max: max)
            } else {
                feedback = "\(ballName(id)): preencha os dois limites, com máximo maior que o mínimo."
                return
            }
        }
        if buy && !stock.values.contains(where: { $0.max != nil }) {
            feedback = "Configure os limites de pelo menos uma bola."
            return
        }
        saving = true
        defer { saving = false }
        do {
            try await profile.save(nick: snapshot.nick, capture: capture, buy: buy, stock: stock)
            feedback = "Ajustes salvos."
        } catch {
            feedback = error.localizedDescription
        }
    }
}





