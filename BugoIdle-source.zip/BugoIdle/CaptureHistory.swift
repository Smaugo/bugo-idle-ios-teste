import SwiftUI
import UIKit

struct CaptureHistory: View {
    @ObservedObject var profile: Profile
    @State private var page = 0
    @State private var clear = false
    private let pageSize = 10
    private let panel = Color(red: 0.16, green: 0.10, blue: 0.25)
    private let lavender = Color(red: 0.81, green: 0.67, blue: 0.94)

    var body: some View {
        let state = profile.state
        let captures = state?.history ?? []
        let pages = max(1, (captures.count + pageSize - 1) / pageSize)
        let current = min(page, pages - 1)
        let farm = state?.farm ?? []
        let best = captures.indices.max { left, right in
            let lhs = captures[left]
            let rhs = captures[right]
            if lhs.Note != rhs.Note { return (lhs.Note ?? -.infinity) < (rhs.Note ?? -.infinity) }
            if lhs.Iv != rhs.Iv { return (lhs.Iv ?? -1) < (rhs.Iv ?? -1) }
            return left > right
        }
        VStack(alignment: .leading, spacing: 9) {
            HStack {
                Text(state?.nick.isEmpty == false ? state?.nick ?? "" : "Histórico de capturas").font(.headline)
                Spacer()
                Button("Limpar") { clear = true }
                    .font(.caption.bold()).buttonStyle(.bordered)
                    .tint(.pink).disabled(captures.isEmpty)
            }
            if let state, !state.nick.isEmpty { session(state) }
            Text("\(captures.count) capturas · página \(current + 1)/\(pages)")
                .font(.subheadline.bold()).foregroundStyle(lavender)
            DisclosureGroup {
                if farm.isEmpty { Text("Nenhuma recompensa registrada.").padding(.vertical, 6) }
                ForEach(farm, id: \.day) { day in
                    VStack(alignment: .leading, spacing: 3) {
                        Text("\(day.day) · \(day.gold.formatted()) ouro").bold().foregroundStyle(.yellow)
                        ForEach(day.items, id: \.name) { item in
                            Text("\(item.quantity.formatted()) × \(item.name)")
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.vertical, 5)
                }
            } label: {
                let coins = farm.reduce(0) { $0 + $1.gold }
                let items = farm.flatMap(\.items).reduce(0) { $0 + $1.quantity }
                Text("Histórico de farm · \(coins.formatted()) ouro · \(items.formatted()) itens").bold()
            }
            .font(.caption).padding(8).background(panel, in: RoundedRectangle(cornerRadius: 6))
            if captures.isEmpty { Text("Nenhuma captura registrada neste aparelho.").font(.footnote) }
            ForEach(Array(captures.dropFirst(current * pageSize).prefix(pageSize).enumerated()), id: \.offset) { offset, capture in
                CaptureCard(capture: capture, rank: current * pageSize + offset == best)
            }
            HStack {
                Button("← Anterior") { page = current - 1 }.disabled(current == 0)
                Spacer()
                Button("Próxima →") { page = current + 1 }.disabled(current + 1 >= pages)
            }.buttonStyle(.bordered).font(.caption.bold())
        }
        .padding(12)
        .background(Color(red: 0.12, green: 0.07, blue: 0.20), in: RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).strokeBorder(lavender.opacity(0.65)))
        .confirmationDialog("Limpar as capturas desta conta?", isPresented: $clear, titleVisibility: .visible) {
            Button("Limpar capturas", role: .destructive) {
                if let nick = state?.nick { Task { await profile.clearHistory(nick: nick) } }
                page = 0
            }
        }
    }

    private func session(_ state: Snapshot) -> some View {
        let online = state.online == true
        let start = date(state.sessionStart)
        let duration = max(1, Date().timeIntervalSince(start))
        let total = state.sessionCaptures ?? 0
        let balls = state.`throws`.sorted { $0.key > $1.key }.map {
            "\(captureBall(Int($0.key))) \($0.value.formatted())"
        }.joined(separator: " · ")
        return VStack(alignment: .leading, spacing: 5) {
            Text(online ? "● Conectada · último sinal \(date(state.lastSignal).formatted(date: .omitted, time: .standard))" : "● Desconectada")
                .foregroundStyle(online ? .green : lavender)
            VStack(alignment: .leading, spacing: 5) {
                Text("Sessão desde \(start.formatted(date: .numeric, time: .shortened)) · \(Duration.seconds(Int(duration)).formatted(.time(pattern: .hourMinuteSecond)))")
                    .foregroundStyle(lavender)
                HStack {
                    metric(total.formatted(), "Capturas")
                    metric((state.sessionShinies ?? 0).formatted(), "Shinies")
                    metric((Double(total) * 3600 / duration).formatted(.number.precision(.fractionLength(1))), "Capturas/h")
                }
                Text("Bolas lançadas").bold().foregroundStyle(lavender)
                Text(balls.isEmpty ? "—" : balls)
            }.padding(8).background(panel, in: RoundedRectangle(cornerRadius: 6))
        }.font(.caption)
    }

    private func metric(_ value: String, _ label: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(value).font(.headline)
            Text(label).foregroundStyle(lavender)
        }.frame(maxWidth: .infinity, alignment: .leading)
    }

    private func date(_ millis: Double?) -> Date {
        millis.map { Date(timeIntervalSince1970: $0 / 1000) } ?? Date()
    }
}

private struct CaptureCard: View {
    let capture: Capture
    let rank: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .top, spacing: 10) {
                sprite.frame(width: 60, height: 60).accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 3) {
                    Text("\(capture.Name ?? capture.text)\(capture.Level.map { "  Nv " + $0.formatted() } ?? "")").font(.headline)
                    if let account = capture.Account { Text(account) }
                    Text(Date(timeIntervalSince1970: capture.at / 1000).formatted(date: .numeric, time: .standard))
                        .font(.caption).foregroundStyle(.white.opacity(0.75))
                }.frame(maxWidth: .infinity, alignment: .leading)
                if rank || capture.Shiny == true {
                    Image(systemName: rank ? "trophy.fill" : "sparkles").foregroundStyle(.yellow)
                        .accessibilityLabel(rank ? "Maior nota" : "Shiny")
                }
            }
            HStack(spacing: 5) {
                badge("P", capture.Power, capture.Power == 1 ? .gray : .green)
                badge("IV ", capture.Iv, (capture.Iv ?? 0) >= 150 ? .cyan : .green)
                badge("Q ", capture.Quality, .green)
                badge("N ", capture.Note, .gray)
            }
            Text(captureBall(capture.Ball))
        }
        .font(.subheadline)
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LinearGradient(colors: [Color(red: 0.33, green: 0.18, blue: 0.16), Color(red: 0.18, green: 0.11, blue: 0.19)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 12))
        .overlay(RoundedRectangle(cornerRadius: 12).strokeBorder(rank ? .yellow : .orange, lineWidth: rank ? 2 : 1))
    }

    @ViewBuilder private var sprite: some View {
        if let photo = capture.Photo, photo.hasPrefix("data:image/png;base64,"),
           let data = Data(base64Encoded: String(photo.dropFirst("data:image/png;base64,".count))),
           let image = UIImage(data: data) {
            Image(uiImage: image).interpolation(.none).resizable().scaledToFit()
        } else {
            Image(systemName: "circle.lefthalf.filled").font(.title).foregroundStyle(.white.opacity(0.5))
        }
    }

    @ViewBuilder private func badge(_ label: String, _ value: Double?, _ color: Color) -> some View {
        if let value {
            Text("\(label)\(value.formatted(.number.precision(.fractionLength(0...3))))")
                .font(.caption2.weight(.heavy).monospacedDigit()).padding(.horizontal, 7).padding(.vertical, 4)
                .background(LinearGradient(colors: [color.opacity(0.80), color.opacity(0.52)], startPoint: .top, endPoint: .bottom), in: RoundedRectangle(cornerRadius: 5))
                .overlay(RoundedRectangle(cornerRadius: 5).strokeBorder(color.opacity(0.9)))
                .foregroundStyle(.black)
        }
    }
}

private func captureBall(_ id: Int?) -> String {
    switch id {
    case 4: "Ultra Ball"
    case 2: "Great Ball"
    case 1: "Poké Ball"
    default: "Não informada"
    }
}


