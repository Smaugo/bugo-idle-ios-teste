(() => {
if (location.origin !== 'https://pokeidle.io' || !location.pathname.startsWith('/app') || window !== window.top) return;
// ==UserScript==
// @name         PokeIdle - Painel geral
// @namespace    pokeidle-auto-captura
// @version      2.2.0-bookidle
// @description  Captura, filtros, reservas, regras de bolas, estoque e histórico em um painel.
// @match        https://pokeidle.io/app*
// @run-at       document-start
// @grant        none
// @sandbox      raw
// @noframes
// ==/UserScript==

(() => {
    'use strict';
    const IDS = [4, 2, 1];
    const BOLAS = { 4: 'Ultra Ball', 2: 'Great Ball', 1: 'Poké Ball' };
    const normalizar = s => String(s ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim().toLowerCase();
    const inteiro = n => Number.isSafeInteger(n) && n >= 0;
    const padrao = () => ({
        capture: false, filter: false, reserve: false, rules: false, alerts: false, buy: false, refresh: false,
        mode: 'all', names: [], pokemonRules: [],
        stock: Object.fromEntries(IDS.map(id => [id, { reserve: 0, min: null, max: null }]))
    });

    function escolherBola(config, nome, estoque) {
        const regra = config.rules && config.pokemonRules.find(r => normalizar(r.name) === normalizar(nome));
        const ordem = regra ? (regra.fallback ? IDS.slice(IDS.indexOf(regra.ball)) : [regra.ball]) : IDS;
        return ordem.find(id => inteiro(estoque?.[id]) && estoque[id] > (config.reserve ? config.stock[id].reserve : 0)) ?? null;
    }

    function aceitarPokemon(config, nome, capturado) {
        if (!config.filter) return true;
        if (config.names.length && !config.names.some(n => normalizar(n) === normalizar(nome))) return false;
        if (config.mode === 'all') return true;
        if (capturado === null) return false;
        return config.mode === 'caught' ? capturado : !capturado;
    }

    function quantidadeCompra(atual, minimo, maximo, ouro, preco, completando = false) {
        if (![atual, minimo, maximo, ouro].every(inteiro) || !Number.isSafeInteger(preco) || preco <= 0) return 0;
        if (maximo <= minimo || atual >= maximo || (!completando && atual > minimo)) return 0;
        return Math.max(0, Math.min(9999, maximo - atual, Math.floor(ouro / preco)));
    }

    function mesclarDados(anterior, parcial) {
        const novo = parcial.cheio ? {} : { ...anterior };
        for (const chave of ['nick', 'gold', 'balls', 'pokedex', 'automation']) {
            if (Object.hasOwn(parcial, chave)) novo[chave] = parcial[chave];
        }
        if (parcial.dexMud || parcial.dexFora) {
            novo.pokedex = { ...novo.pokedex, ...parcial.dexMud };
            for (const id of parcial.dexFora ?? []) delete novo.pokedex[id];
        }
        return novo;
    }

    function validarConfig(c) {
        if (!c || !['all', 'caught', 'new'].includes(c.mode)) throw Error('Escolha um filtro válido.');
        if (c.refresh === undefined) c.refresh = true; // Migra as configurações anteriores sem perder os filtros.
        for (const key of ['capture', 'filter', 'reserve', 'rules', 'alerts', 'buy', 'refresh']) {
            if (typeof c[key] !== 'boolean') throw Error('Controle inválido.');
        }
        if (!Array.isArray(c.names) || c.names.some(n => typeof n !== 'string' || !n.trim())) throw Error('Revise os nomes.');
        for (const id of IDS) {
            const s = c.stock?.[id];
            if (!s || !inteiro(s.reserve) || ![s.min, s.max].every(n => n === null || inteiro(n))) throw Error('Use quantidades inteiras e positivas ou zero.');
            if (s.max !== null && (s.min === null || s.max <= s.min)) throw Error(`${BOLAS[id]}: máximo deve ser maior que mínimo.`);
        }
        if (!Array.isArray(c.pokemonRules)) throw Error('Regras inválidas.');
        const nomes = new Set();
        for (const r of c.pokemonRules) {
            const n = normalizar(r.name);
            if (!n || !IDS.includes(r.ball) || typeof r.fallback !== 'boolean' || nomes.has(n)) throw Error('Revise as regras: um nome por Pokémon, sem duplicatas.');
            nomes.add(n);
        }
        return c;
    }

    // O mesmo código de decisão é usado pelos testes locais, sem executar o navegador.
    if (typeof module === 'object' && module.exports) {
        module.exports = { padrao, escolherBola, aceitarPokemon, quantidadeCompra, mesclarDados, validarConfig };
        return;
    }
    if (window.__pokeidlePainelGeral) return;
    window.__pokeidlePainelGeral = true;

    let cfg = padrao(), eu = null, socket = null, catalogoBolas = [], conta = null;
    let pausa = false, pendente = null, repondo = null, ultimaCompra = 0, ultimoEstado = 0;
    let mensagem = 'Aguardando conexão. Se necessário, recarregue o jogo.', falha = '';
    let historico = [], especies = new Map(), dexAPI = null, catalogoPronto = false, posicao = null;
    let ultimoCapturado = '', memoriaAviso = '';
    const RECUPERACAO = 'pokeidle-painel-v2:recuperacao';
    const ULTIMA_RECARGA = 'pokeidle-painel-v2:ultima-recarga';
    let recuperar = null;
    try {
        const r = JSON.parse(sessionStorage.getItem(RECUPERACAO));
        if (r && typeof r.nick === 'string' && Number.isFinite(r.at)
            && Date.now() >= r.at && Date.now() - r.at < 15 * 60 * 1000) recuperar = r;
    } catch { /* Sem restauração quando o armazenamento não estiver disponível. */ }
    let ultimoSinal = Date.now(), conectou = !!recuperar, pausaRede = false, bloqueioSessao = false, recarregando = false;
    const capturasVistas = new Set();
    const limitesEstoque = new Map();
    const prefixoHistorico = 'pokeidle-painel-v2:';
    let corteGlobal = 0;
    const cortesPorConta = new Map();
    const corte = nick => Math.max(corteGlobal, cortesPorConta.get(nick.toLowerCase()) ?? 0);
    const chave = tipo => `pokeidle-painel-v2:${conta}:${tipo}`;
    const numero = n => inteiro(n) ? n.toLocaleString('pt-BR') : '—';

    function guardar(tipo, valor) {
        if (!conta) return;
        try { localStorage.setItem(chave(tipo), JSON.stringify(valor)); return true; }
        catch { falha = 'O navegador não permitiu salvar. As alterações valem só nesta página.'; }
    }
    function ler(tipo, fallback) {
        try { return JSON.parse(localStorage.getItem(chave(tipo))) ?? fallback; }
        catch { return fallback; }
    }
    function carregarConta(nick) {
        if (!nick || conta === nick) return;
        conta = nick;
        sessionStart = Date.now(); sessionCaptures = 0; sessionShinies = 0; throws = {};
        try { cfg = validarConfig(ler('config', padrao())); } catch { cfg = padrao(); }
        pausa = ler('pausa', false) === true;
        pendente = null; repondo = null; ultimaCompra = 0;
        limitesEstoque.clear(); ultimoCapturado = ''; falha = '';
        if (recuperar?.nick === nick) {
            cfg.capture = recuperar.capture === true;
            cfg.buy = recuperar.buy === true;
            pausa = recuperar.paused === true;
        }
        if (ler('compra-pendente', false) === true) {
            cfg.buy = false;
            guardar('config', cfg);
        }
        recuperar = null;
        try { sessionStorage.removeItem(RECUPERACAO); } catch { /* Não impede a conexão. */ }
        historico = ler('capturas', []);
        if (!Array.isArray(historico)) historico = [];
        historico = historico.filter(r => typeof r?.text === 'string' && Number.isFinite(r.at) && r.at > corte(nick)).slice(0, 100);
        capturasVistas.clear();
        posicao = ler('posicao', null);
    }

    window.__bookidleHistoryCutoff = (nick, at) => {
        if (!Number.isSafeInteger(at) || at <= 0 || (nick !== null && typeof nick !== 'string')) return;
        if (nick === null) corteGlobal = Math.max(corteGlobal, at);
        else cortesPorConta.set(nick.toLowerCase(), Math.max(corte(nick), at));
        try {
            for (const key of Object.keys(localStorage)) {
                if (!key.startsWith(prefixoHistorico) || !key.endsWith(':capturas')) continue;
                const nome = key.slice(prefixoHistorico.length, -':capturas'.length);
                if (nick !== null && nome.toLowerCase() !== nick.toLowerCase()) continue;
                const registros = JSON.parse(localStorage.getItem(key));
                if (Array.isArray(registros)) localStorage.setItem(key, JSON.stringify(registros.filter(r => r?.at > corte(nome))));
            }
        } catch {
            falha = 'A limpeza foi aplicada nesta página. O navegador não permitiu atualizar o histórico local.';
        }
        if (conta && (nick === null || nick.toLowerCase() === conta.toLowerCase())) {
            historico = historico.filter(r => r.at > corte(conta));
            ultimoCapturado = historico[0]?.text ?? '';
        }
    };

    function pararPorFalha(texto) {
        cfg.capture = false;
        cfg.buy = false;
        pausa = true;
        repondo = null;
        falha = texto;
        guardar('config', cfg); guardar('pausa', pausa);
    }

    function confirmarEstoque(estoque) {
        if (!estoque) return;
        for (const [id, limite] of limitesEstoque) if (estoque[id] <= limite) limitesEstoque.delete(id);
        if (!pendente) return;
        const quantidade = estoque[pendente.id];
        if (quantidade >= pendente.before + pendente.qty) {
            guardar('compra-pendente', false);
            mensagem = `Reposição confirmada: ${pendente.qty} ${BOLAS[pendente.id]}.`;
            pendente = null;
        }
    }

    const keys = ['hp','atk','def','spAtk','spDef','speed'];
    const num = value => typeof value === 'number' && Number.isFinite(value) ? value : null;
    const seen = new Set();
    let assets, shinyLooks = {};
    let sessionStart = Date.now(), sessionCaptures = 0, sessionShinies = 0, throws = {};
    function send(row, update = false) {
        if (row.Account !== conta) return;
        const existing = historico.find(entry => entry.Id === row.Id);
        if (existing) Object.assign(existing, row);
        else if (!update) historico.unshift({ ...row, at: row.At, text: row.Name });
        historico.length = Math.min(historico.length, 100);
        guardar('capturas', historico);
    }
    window.bugoLimpar = nick => {
        if (!eu || !conta || nick !== conta) return false;
        if (!guardar('capturas', [])) return false;
        historico = [];
        publicarMobile();
        return true;
    };
 const carregarSprites=()=>Promise.all([
  ...['creatures','creatures-novos','creatures-outland-novos','creatures-formas'].map(n=>fetch('/assets/'+n+'.json').then(r=>r.json())),
  fetch('/assets/site/assets/maps/marker-atlas.json').then(r=>r.json()),
  import('/shared/nota-pokemon.mjs'),import('/shared/linhagem-nota.mjs'),import('/shared/outland.mjs'),import('/sprites.mjs')
 ]).then(async all=>{
  const list=all.slice(0,4).flatMap(x=>x.creatures??[]),atlas=all[4],note=all[5];
  all[7].aplicarRemapOutlandLista(list);const species=new Map(list.map(e=>[e.pokeId,e]));
  all[6].anotarLinhagemDaNota(list,id=>species.get(id));
  const url=new URL(atlas.image||'/assets/site/assets/maps/marker-atlas.png',location.origin);
  if(url.origin!==location.origin)throw Error('Atlas externo');
  const image=new Image();image.src=url.href;await image.decode();
  return assets={species,list,atlas,image,note,sprites:all[8]};
 }).catch(()=>null);
 async function record(p,ball,at,account,historical=false){
  if(!p||!account)return;
  const id=String(p.id ?? (at + ':' + Math.random())),key=account.toLowerCase()+':'+id;
  if(seen.has(key))return;seen.add(key);if(seen.size>6000)seen.delete(seen.values().next().value);
  const ivs=keys.map(k=>num(p.ivs?.[k]));
  const row={Historical:historical,Id:id,Account:account,Name:String(p.nome??'Pokémon').slice(0,80),At:at,Level:num(p.level),Power:num(p.potencia),Quality:num(p.quality),Shiny:p.shiny===true,Iv:ivs.every(v=>v!==null)?ivs.reduce((a,b)=>a+b,0):num(p.ivTotal),Ivs:ivs,Ball:num(ball),Note:num(p.nota),Photo:null};
  send(row);
  const a=await (assets ??= carregarSprites());if(!a)return;
  const species=a.species.get(p.speciesId)||a.list.find(e=>e.name===p.nome);
  if(species&&row.Iv!==null&&row.Quality!==null&&row.Power!==null){try{row.Note=num(a.note.notaDePokemon(p,species));}catch{}}
  const look=p.shiny?(p.lookShiny??shinyLooks[p.speciesId]):(species?.looktype??p.looktype);
  const slot=a.atlas.slots?.[String(look)];
  if(Array.isArray(slot)&&slot.length===2){try{const c=document.createElement('canvas');c.width=c.height=64;const ctx=c.getContext('2d');ctx.imageSmoothingEnabled=false;const cell=a.atlas.cell||64;ctx.drawImage(a.image,slot[0]*cell,slot[1]*cell,cell,cell,0,0,64,64);row.Photo=c.toDataURL('image/png');}catch{}}
  if(!row.Photo&&look){try{
   const sprite=await a.sprites.carregarOutfit(look);const frame=sprite&&a.sprites.quadrosDe(sprite,3)[0];const page=frame&&sprite.imagens[frame.pagina];
   if(page&&frame){const c=document.createElement('canvas');c.width=c.height=64;const ctx=c.getContext('2d');ctx.imageSmoothingEnabled=false;const scale=Math.min(64/frame.w,64/frame.h,1);const w=Math.max(1,Math.round(frame.w*scale)),h=Math.max(1,Math.round(frame.h*scale));ctx.drawImage(page,frame.x,frame.y,frame.w,frame.h,(64-w)>>1,64-h-2,w,h);row.Photo=c.toDataURL('image/png');}
  }catch{}}
  send(row, true);
 }
    function registrarFarm(eventos) {
        if (!conta) return;
        const registros = ler('farm-mobile', []);
        const hoje = new Date().toLocaleDateString('sv-SE');
        let dia = registros.find(row => row.day === hoje);
        if (!dia) {
            dia = { day: hoje, gold: 0, items: [] };
            registros.unshift(dia);
        }
        let mudou = false;
        for (const evento of eventos) {
            if (evento?.k !== 'bossMorto' && (evento?.k !== 'morte' || evento.quem !== 'selvagem')) continue;
            const ouro = evento.k === 'bossMorto' ? evento.valor : evento.ouro;
            if (inteiro(ouro) && ouro > 0) { dia.gold += ouro; mudou = true; }
            for (const drop of (Array.isArray(evento.drops) ? evento.drops.slice(0, 100) : [])) {
                const qtd = drop?.qtd ?? 1;
                const nome = typeof drop?.nome === 'string' && drop.nome.trim() || (drop?.itemId ? '#' + drop.itemId : '');
                if (!nome || !inteiro(qtd) || !qtd) continue;
                const item = dia.items.find(row => row.name === nome);
                if (item) item.quantity += qtd;
                else dia.items.push({ name: nome, quantity: qtd });
                mudou = true;
            }
        }
        if (mudou) guardar('farm-mobile', registros.slice(0, 90));
    }

    function receber(m) {
        if (['welcome', 'estado', 'batalha', 'vivo'].includes(m.t)) ultimoSinal = Date.now();
        if (m.t === 'erro' && /^(?:auth\.|conta\.)/.test(m.chave ?? '')) {
            bloqueioSessao = true;
            pararPorFalha('A conta precisa de atenção. Auto-refresh suspenso; confira o aviso do jogo.');
        }
        if (m.t === 'welcome') {
            shinyLooks = { ...m.shinyLooks, ...m.shinyLooksOutland };
            eu = null;
            limitesEstoque.clear();
            catalogoBolas = Array.isArray(m.catalogoBolas) ? m.catalogoBolas : [];
            dexAPI?.setOutlandDexMap(m.outlandDex ?? null);
        }
        if ((m.t === 'welcome' || m.t === 'estado') && m.estado && typeof m.estado === 'object') {
            eu = mesclarDados(eu, m.estado);
            carregarConta(eu.nick);
            if (m.t === 'welcome' && eu.nick) {
                conectou = true;
                if (cfg.refresh && !bloqueioSessao) {
                    pausaRede = false;
                    falha = '';
                }
            }
            ultimoEstado = Date.now();
            if (Object.hasOwn(m.estado, 'balls') && eu.balls) {
                limitesEstoque.clear();
                confirmarEstoque(Object.fromEntries(IDS.map(id => [id, eu.balls[id] ?? 0])));
            }
        }
        if (m.t === 'batalha' && Array.isArray(m.ev)) {
            registrarFarm(m.ev);
            const capturas = m.ev.filter(evento => evento?.k === 'capturado' && evento.pokemon);
            const acertos = m.ev.filter(evento => evento?.k === 'bola' && evento.sucesso === true);
            for (const evento of m.ev) {
                if (evento?.k !== 'bola') continue;
                const id = evento.ballId ?? 0;
                throws[id] = (throws[id] ?? 0) + 1;
            }
            for (const evento of capturas) {
                if (!conta) continue;
                const pokemon = evento.pokemon;
                if (pokemon.id != null && capturasVistas.has(pokemon.id)) continue;
                if (pokemon.id != null) capturasVistas.add(pokemon.id);
                if (capturasVistas.size > 500) capturasVistas.delete(capturasVistas.values().next().value);
                sessionCaptures++;
                if (pokemon.shiny === true) sessionShinies++;
                const ball = num(evento.ballId) ?? (capturas.length === 1 && acertos.length === 1 ? num(acertos[0].ballId) : null);
                void record(pokemon, ball, Date.now(), conta).catch(() => {});
            }
        }
        if (m.t === 'erro' && pendente) {
            pendente = null;
            cfg.buy = false;
            guardar('config', cfg);
            repondo = null;
            falha = 'O jogo recusou uma ação durante a compra. Confira o aviso do jogo antes de reativar a recompra.';
        }
    }

    // Observa apenas o socket do jogo; não lê tokens nem abre outra conexão.
    const WebSocketOriginal = window.WebSocket;
    window.WebSocket = new Proxy(WebSocketOriginal, {
        construct(Target, args) {
            const ws = new Target(...args);
            const url = new URL(String(args[0]), location.href);
            if (url.host !== location.host || url.pathname !== '/') return ws;
            socket = ws;
            eu = null;
            ultimoEstado = 0;
            ws.addEventListener('message', evento => {
                if (socket !== ws || typeof evento.data !== 'string') return;
                let m;
                try { m = JSON.parse(evento.data); } catch { return; }
                try { receber(m); }
                catch { pararPorFalha('Os dados do jogo mudaram. Automações pausadas para revisão.'); }
            });
            ws.addEventListener('close', evento => {
                if (socket !== ws) return;
                if ([4000, 4001, 4003].includes(evento.code)) {
                    bloqueioSessao = true;
                    pararPorFalha('Sessão encerrada pelo jogo ou aberta em outro lugar. Auto-refresh suspenso.');
                } else {
                    pausaRede = true;
                    if (pendente) cfg.buy = false;
                    falha = 'Conexão interrompida. Aguardando reconexão; auto-refresh após 60 segundos sem resposta.';
                }
                socket = null;
                eu = null;
                pendente = null;
                repondo = null;
            });
            return ws;
        }
    });

    function vigiarConexao() {
        if (recarregando) return true;
        if (!cfg.refresh || !conectou || bloqueioSessao || navigator.onLine === false) return false;
        if (Date.now() - ultimoSinal < 60000) return false;
        try {
            const ultima = Number(sessionStorage.getItem(ULTIMA_RECARGA)) || 0;
            if (ultima && Date.now() - ultima < 180000) return false;
            const estado = conta ? { nick: conta, capture: cfg.capture, buy: cfg.buy && !pendente, paused: pausa } : recuperar;
            if (!estado) return false;
            sessionStorage.setItem(RECUPERACAO, JSON.stringify({ ...estado, at: Date.now() }));
            sessionStorage.setItem(ULTIMA_RECARGA, String(Date.now()));
            guardar('config', cfg);
        } catch {
            falha = 'Auto-refresh indisponível: o navegador não permitiu salvar o controle de recargas.';
            return false;
        }
        recarregando = true;
        mensagem = 'Conexão sem resposta há 60 segundos. Recarregando o jogo…';
        location.reload();
        return true;
    }

    async function carregarEspecies() {
        try {
            const [dex, outland, ...dados] = await Promise.all([
                import('/shared/pokedex.mjs'), import('/shared/outland.mjs'),
                ...['creatures', 'creatures-novos', 'creatures-outland-novos', 'creatures-formas'].map(async nome => {
                    const r = await fetch(`/assets/${nome}.json`);
                    if (!r.ok) throw Error('Catálogo indisponível');
                    return r.json();
                })
            ]);
            const lista = dados.flatMap(d => d.creatures ?? []);
            outland.aplicarRemapOutlandLista(lista);
            for (const e of lista) {
                if (!outland.isEspelhoFantasmaPokeId(e.pokeId)) especies.set(normalizar(e.name), e.pokeId);
            }
            dexAPI = dex;
            catalogoPronto = true;
        } catch {
            mensagem = 'Não foi possível carregar o catálogo. Filtros de já capturado aguardam uma recarga.';
        }
    }

    function jaCapturado(nome) {
        if (!catalogoPronto || !eu?.pokedex || !especies.has(normalizar(nome))) return null;
        const id = especies.get(normalizar(nome));
        const dex = dexAPI.chavePokedex(id);
        if (dex == null) return null;
        return (eu.pokedex[dex]?.c ?? 0) + (id !== dex ? eu.pokedex[id]?.c ?? 0 : 0) > 0;
    }

    function estoqueAtual() {
        if (!eu?.balls || typeof eu.balls !== 'object') return null;
        const estoque = Object.fromEntries(IDS.map(id => [id, eu.balls[id] ?? 0]));
        for (const botao of document.querySelectorAll('#auto-ball-opts button.auto-chip')) {
            const id = bolaDoBotao(botao);
            const texto = botao.querySelector('.q')?.textContent.trim() ?? '';
            // Não interpreta abreviações como "1,2 mil" como se fossem uma quantidade exata.
            if (id && /^(?:\d+|\d{1,3}(?:[.\s]\d{3})+)$/.test(texto)) {
                const quantidade = Number(texto.replace(/[.\s]/g, ''));
                if (inteiro(quantidade)) estoque[id] = quantidade;
            }
        }
        return Object.values(estoque).every(inteiro) ? estoque : null;
    }
    function bolaDoBotao(botao) {
        for (const el of botao.querySelectorAll('img, span')) {
            const nome = /\bball-(ultra|great|poke)\.png\b/i.exec(el.getAttribute('src') || el.style.backgroundImage);
            if (nome) return { ultra: 4, great: 2, poke: 1 }[nome[1].toLowerCase()];
        }
        return null;
    }
    function nativasLigadas() {
        const a = eu?.automation;
        return a?.autoBall || a?.autoBallAteCapturar || a?.autoBallSemParar;
    }

    function tentarComprar(estoque) {
        if (!cfg.buy || Date.now() - ultimaCompra < 3000) return false;
        if (repondo !== null && estoque[repondo] >= cfg.stock[repondo].max) repondo = null;
        const ids = repondo === null ? IDS : [repondo];
        for (const id of ids) {
            if (limitesEstoque.has(id)) continue;
            const s = cfg.stock[id];
            const b = catalogoBolas.find(bola => Number(bola.id) === id);
            if (!b?.compravel) continue;
            const qty = quantidadeCompra(estoque[id], s.min, s.max, eu.gold, b.priceGold, repondo === id);
            if (!qty) continue;
            if (!guardar('compra-pendente', true)) { cfg.buy = false; return false; }
            pendente = { id, before: estoque[id], qty, at: Date.now() };
            repondo = id;
            ultimaCompra = Date.now();
            try {
                socket.send(JSON.stringify({ t: 'shop.buy', kind: 'ball', id, qty }));
                mensagem = `Repondo ${qty} ${BOLAS[id]} por ${numero(qty * b.priceGold)} ouro…`;
            } catch {
                pendente = null;
                pararPorFalha('Não foi possível enviar a compra. Confira a conexão.');
            }
            return true;
        }
        repondo = null;
        return false;
    }

    function tentarCapturar(estoque) {
        if (!cfg.capture) return;
        const painel = document.querySelector('#caidos');
        if (!painel || painel.classList.contains('hidden') || !painel.getClientRects().length) {
            mensagem = 'Aguardando Pokémon próximos para capturar.';
            return;
        }
        let desconhecido = false;
        for (const alvo of painel.querySelectorAll('#caidos-lista button.caido:not(:disabled)')) {
            const label = alvo.querySelector('.caido-quem');
            if (!label) continue;
            const copia = label.cloneNode(true);
            copia.querySelector('b')?.remove();
            const nome = copia.textContent.trim();
            const capturado = cfg.filter && cfg.mode !== 'all' ? jaCapturado(nome) : null;
            if (cfg.filter && cfg.mode !== 'all' && capturado === null) desconhecido = true;
            if (!aceitarPokemon(cfg, nome, capturado)) continue;
            const disponivel = Object.fromEntries(IDS.map(id => [id, Math.min(estoque[id], limitesEstoque.get(id) ?? estoque[id])]));
            const id = escolherBola(cfg, nome, disponivel);
            if (!id) continue;
            const botao = [...painel.querySelectorAll('#caidos-bolas button.caidos-bola:not(:disabled)')].find(b => bolaDoBotao(b) === id);
            if (!botao) continue;
            if (!botao.classList.contains('on')) {
                botao.click();
                mensagem = `Selecionando ${BOLAS[id]} para ${nome}.`;
                return;
            }
            // Conta a bola em trânsito para preservar a reserva sem esperar a resposta do arremesso.
            limitesEstoque.set(id, disponivel[id] - 1);
            alvo.click();
            mensagem = `Tentando ${nome} com ${BOLAS[id]}.`;
            return;
        }
        mensagem = desconhecido ? 'Pokédex ou espécie não identificada: aguardando dados, sem arriscar o filtro.' : 'Nenhum alvo atende aos filtros com as bolas disponíveis e a reserva atual.';
    }

    function ciclo() {
        if (vigiarConexao()) return;
        const estoque = estoqueAtual();
        confirmarEstoque(estoque);
        if (pendente && Date.now() - pendente.at > 12000) {
            pendente = null;
            cfg.buy = false;
            guardar('config', cfg);
            repondo = null;
            falha = 'Sem confirmação de estoque após a compra. Recompra desligada; confira o estoque antes de reativá-la.';
        }
        if (!socket || socket.readyState !== 1 || !estoque) mensagem = 'Aguardando dados do jogo. Recarregue se esta mensagem persistir.';
        else if (Date.now() - ultimoEstado > 30000) mensagem = 'Aguardando atualização do estoque.';
        else if (!mobileAtivo || document.hidden || pausa || pausaRede) mensagem = 'Ações pausadas. O histórico continua registrando suas capturas.';
        else if (nativasLigadas()) mensagem = 'Desligue o lançamento automático nativo para evitar capturas fora dos filtros.';
        else if (!pendente) {
            if (!tentarComprar(estoque)) {
                if (cfg.capture) tentarCapturar(estoque);
                else mensagem = cfg.buy ? 'Recompra ligada: aguardando estoque mínimo e ouro suficiente.' : 'Captura e recompra desligadas. Configure e ative quando quiser.';
            }
        }
    }

    let mobileAtivo = false;
    window.bugoAtivo = ativo => { mobileAtivo = ativo === true; };
    window.bugoSalvar = (nick, capture, buy, stock) => {
        if (!eu || !conta || nick !== conta || pendente || bloqueioSessao) return false;
        stock = Object.fromEntries(IDS.map(id => [id, { reserve: 0, min: stock[id]?.min ?? null, max: stock[id]?.max ?? null }]));
        const next = { ...cfg, capture, buy, stock };
        try { validarConfig(next); } catch { return false; }
        if (buy && !IDS.some(id => stock[id].max !== null)) return false;
        if (!guardar('config', next)) return false;
        if (buy && ler('compra-pendente', false) && !guardar('compra-pendente', false)) return false;
        cfg = next;
        repondo = null;
        pausaRede = false;
        falha = '';
        publicarMobile();
        return true;
    };
    function publicarMobile() {
        const bridge = window.webkit?.messageHandlers?.bugo;
        if (!bridge) return;
        bridge.postMessage({
            nick: eu?.nick ?? '', gold: eu?.gold ?? null,
            stock: estoqueAtual(), config: cfg, history: eu?.nick ? historico : [],
            online: socket?.readyState === 1, lastSignal: ultimoSinal, sessionStart, sessionCaptures, sessionShinies, throws,
            status: falha || mensagem, farm: eu?.nick ? ler('farm-mobile', []) : []
        });
    }
    setInterval(() => {
        try { ciclo(); publicarMobile(); } catch { pararPorFalha('Não foi possível ler a interface. Automações pausadas para revisão.'); }
    }, 1000);
})();

})();







