# Changelog

## Em desenvolvimento

- Criada a distribuição independente Bugo-Idle iOS, com quatro perfis WebKit, captura, recompra entre mínimo e máximo, histórico de capturas e recompensas por dia.
- Testes no Windows com Node.js cobrem sintaxe, limites, sessão, bloqueio em segundo plano, envio e confirmação simulada de compra, clique simulado de captura e registro de itens e ouro. Compilação e teste em iPhone pendentes.
- Banco sem impacto. O app guarda dados do jogo e preferências no armazenamento local de cada perfil WebKit. O pacote inclui apenas fontes e recursos do projeto.
- Incluída prévia HTML interativa e configuração de build macOS remoto para iniciar a beta pelo Windows. Build no Codemagic ainda não executada.

- Histórico iOS ganhou cartões com sprites do jogo, P, IV, Q, nota, sessão, farm recolhível e paginação. Prévia HTML atualizada com dados simulados. Teste de sintaxe e smoke test passaram no Node. Validação no iPhone pendente. Sem migração de banco.
- Adicionado workflow manual para gerar IPA sem assinatura para teste pessoal. Execução em macOS e instalação pendentes. Sem impacto no banco.
- iOS 0.1.1 mantém os quatro jogos abertos no app em primeiro plano ao alternar contas ou consultar o histórico. Captura usa o painel ativo do jogo mesmo quando recolhido. Teste simulado verifica captura recolhida e pausa ao sair do app. Sem impacto no banco.
- iOS 0.1.2 toca um alerta curto ao confirmar nova captura durante a sessão, inclusive em contas recolhidas. O som foi recriado em dois tons. Teste simulado do JavaScript e inspeção do WAV no Windows. Compilação e reprodução no iPhone pendentes. Sem impacto no banco.
- iOS 0.1.3 carrega sprites do catálogo e atlas do pokeidle.io independentemente do cálculo de nota, tenta completar capturas antigas e mantém o troféu pela melhor nota (IV na ausência de nota). Indicadores receberam contraste e cores por faixa. Smoke test no Node passou. Banco sem migração. Build e teste no aparelho pendentes.
